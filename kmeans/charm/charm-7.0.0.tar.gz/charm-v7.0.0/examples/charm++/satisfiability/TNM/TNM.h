#ifndef _TNM_H_
#define _TNM_H_

#include <vector>

using namespace std;

bool seq_processing(int _var_size, const vector< vector<int> >& clauses);

#endif
