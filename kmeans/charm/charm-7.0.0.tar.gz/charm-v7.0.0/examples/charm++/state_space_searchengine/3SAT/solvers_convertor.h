#ifndef SOLVERS_CONVERTOR_H_
#define SOLVERS_CONVERTOR_H_
bool convertToSequential(StateBase *_base);
#endif
