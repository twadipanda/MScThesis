A simple liveViz poll server. Python commands will 
cause images to be generated, while liveviz requests 
will retrieve these server generated images.

Use ccs_tools/bin/lvClient with this server.

Author: Isaac Dooley 8-18-05
