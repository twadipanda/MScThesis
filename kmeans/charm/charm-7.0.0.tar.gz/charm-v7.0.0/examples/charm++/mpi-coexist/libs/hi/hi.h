//interface for invocation from MPI
void HiStart(int elems);
