//interface for invocation from MPI
void HelloStart(int elems);

