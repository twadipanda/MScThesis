This example performs vector addition with a chare array. There is no
decomposition involved, as each chare computes an independent set of vectors.

Usage: ./vecadd -c [chares] -s [vector size]
