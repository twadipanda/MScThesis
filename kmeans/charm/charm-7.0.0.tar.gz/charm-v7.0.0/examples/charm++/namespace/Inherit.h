#include "Inherit.decl.h"
class Driver : public Chare {
  public: 
     Driver(CkArgMsg*);
};
