#include "collidecharm.h"
//interface for invocation from MPI
void detectCollision(CollisionList *&colls,int nBoxes, bbox3d *boxes, int *prio=NULL);

