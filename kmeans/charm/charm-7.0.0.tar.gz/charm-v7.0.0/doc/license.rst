========================
Charm++/Converse license
========================

.. literalinclude:: ../LICENSE
    :language: none
